package services;

import models.Aluno;

public class SistemaColurnares {
	
	public void atualizarColuna(Aluno aluno, String semestre) {
		System.out.println("Atualizando colunas do aluno " + aluno + " para o semestre" + semestre);
	}
	
}
