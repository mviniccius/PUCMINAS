/*
import java.time.LocalDate;
import java.time.LocalTime;

public class SessaoTecnica extends Atividade {
    private Professor mediador;

    public SessaoTecnica(int codigo, LocalDate data, LocalTime horarioInicio, LocalTime horarioFim, Professor mediador) {
        super(codigo, data, horarioInicio, horarioFim);
        this.mediador = mediador;
    }

    public Professor getMediador() {
        return mediador;
    }

    public void setMediador(Professor mediador) {
        this.mediador = mediador;
    }

    @Override
    public String getTipoAtividade() {
        return "Sessão Técnica";
    }
}

 */