/*

import java.time.LocalDate;
import java.time.LocalTime;
public class MiniCurso extends Atividade {
    private Profissional ministrante;

    public MiniCurso(int codigo, LocalDate data, LocalTime horarioInicio, LocalTime horarioFim, Profissional ministrante) {
        super(codigo, data, horarioInicio, horarioFim);
        this.ministrante = ministrante;
    }

    public Profissional getMinistrante() {
        return ministrante;
    }

    public void setMinistrante(Profissional ministrante) {
        this.ministrante = ministrante;
    }

    @Override
    public String toString() {
        return "MiniCurso{" +
                "ministrante=" + ministrante +
                '}';
    }
}

 */